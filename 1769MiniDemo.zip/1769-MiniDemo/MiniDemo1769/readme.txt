MiniDemo
=====================
Najmniejszy sensowny projekt pokazujący funkcjonowanie MCU
Proszę go rozszerzać o wybrane cechy
